var socket  = require( 'socket.io' );
var express = require('express');
var app     = express();
var server  = require('http').createServer(app);
var io      = socket.listen( server );
var port    = process.env.PORT || 3000;

server.listen(port, function () {
  console.log('Server listening at port %d', port);
});


io.on('connection', function (socket) {
  socket.on( 'new_task', function( data ) {
    io.sockets.emit( 'new_task', {
      data: data
    });
  });
  socket.on( 'new_comment', function( data ) {
    io.sockets.emit( 'new_comment', {
      data: data
    });
  });

  socket.on( 'update_groups_tasks', function() {
    io.sockets.emit( 'update_groups_tasks', {
    });
  });

  
});
