<?php 
include_once('config.php');
$case = isset($_POST['case']) ? $_POST['case'] :null; 
switch ($case) {
    case 1://add task
        $group_input = isset($_POST['group_input'])?other::security($_POST['group_input']):null;
        $task_title = isset($_POST['task_title'])?other::security($_POST['task_title']):null;
        $task_date = isset($_POST['task_date'])?other::security($_POST['task_date']):null;
        $task_status = isset($_POST['task_status'])?other::security($_POST['task_status']):null;
        $task_description = isset($_POST['task_description'])?other::security($_POST['task_description']):null;

        $valid_group = validation::ValidateValue($group_input,'GROUP',array('required','strings','notnumeric',array('is_in_array',array('a','b'))));
        if (is_string($valid_group)==true) {
           echo json_encode(array('type' =>'n' ,'msg'=>$valid_group));return false;exit();
        }

        $valid_title = validation::ValidateValue($task_title,'Title',array('required','strings','notnumeric'));
        if (is_string($valid_title)==true) {
           echo json_encode(array('type' =>'n' ,'msg'=>$valid_title));return false;exit();
        }

        $valid_date = validation::ValidateValue($task_date,'Date',array('required','is_date'));
        if (is_string($valid_date)==true) {
           echo json_encode(array('type' =>'n' ,'msg'=>$valid_date));return false;exit();
        }

        $valid_status = validation::ValidateValue($task_status,'Status',array('required','strings','notnumeric',array('is_in_array',array('Done','Delayed','Pending'))));
        if (is_string($valid_status)==true) {
           echo json_encode(array('type' =>'n' ,'msg'=>$valid_status));return false;exit();
        }
        $task= new task();
        $task->t_title=$task_title;$task->t_description=$task_description;
        $task->status=$task_status;$task->t_group=$group_input;
        $task->t_created=$task_date;$task->t_sort=task::GetMinumSort();
        if ($task->save()) {
            echo json_encode(array('type' =>'success' ,'msg'=>'Task Saved Successfully'));return false;exit();
        }
        break;
    case 2://get task title
        $task_id = isset($_POST['col_id'])?other::security($_POST['col_id']):null;
        $return = task::ReturnSpicifColumn($task_id,'t_title');
        echo json_encode(array('type' =>'success' ,'result' =>$return ,'msg'=>'Returned Successfully'));
        return false;exit();
    break;
    case 3://update task title
        $task_id = isset($_POST['col_id'])?other::security($_POST['col_id']):null;
        $title = isset($_POST['newtitle'])?other::security($_POST['newtitle']):null;
        $valid_title = validation::ValidateValue($title,'Title',array('required','strings','notnumeric'));
        if (is_string($valid_title)==true) {
           echo json_encode(array('type' =>'n' ,'msg'=>$valid_title));return false;exit();
        }
        task::UpdateOneInput($task_id,'t_title',$title);return false;exit();
    break;
    case 4://get task date
        $task_id = isset($_POST['col_id'])?other::security($_POST['col_id']):null;
        $return = task::ReturnSpicifColumn($task_id,'t_created');
        echo json_encode(array('type' =>'success' ,'result' =>$return ,'msg'=>'Returned Successfully'));
        return false;exit();
    break;
    case 5://update task date
        $task_id = isset($_POST['col_id'])?other::security($_POST['col_id']):null;
        $t_created = isset($_POST['created'])?other::security($_POST['created']):null;

        $valid_date = validation::ValidateValue($t_created,'Date',array('required','is_date'));
        if (is_string($valid_date)==true) {
           echo json_encode(array('type' =>'n' ,'msg'=>$valid_date));return false;exit();
        }
        task::UpdateOneInput($task_id,'t_created',$t_created);return false;exit();
    break;
    case 6://get task status
        $task_id = isset($_POST['col_id'])?other::security($_POST['col_id']):null;
        $return = task::ReturnSpicifColumn($task_id,'status');
        echo json_encode(array('type' =>'success' ,'result' =>$return ,'msg'=>'Returned Successfully'));
        return false;exit();
    break;
    case 7://update task date
        $task_id = isset($_POST['col_id'])?other::security($_POST['col_id']):null;
        $status = isset($_POST['status'])?other::security($_POST['status']):null;
        $valid_status = validation::ValidateValue($status,'Status',array('required','strings','notnumeric',array('is_in_array',array('Done','Delayed','Pending'))));
        if (is_string($valid_status)==true) {
           echo json_encode(array('type' =>'n' ,'msg'=>$valid_status));return false;exit();
        }
        task::UpdateOneInput($task_id,'status',$status);return false;exit();
    break;
    case 8://delete task
        $task_id = isset($_POST['col_id'])?other::security($_POST['col_id']):null;
        task::DeleteTask($task_id);
        echo json_encode(array('type' =>'success' ,'msg'=>'Task Deleted Successfully'));return false;exit();
    case 9://get task details
        $task_id = isset($_POST['col_id'])?other::security($_POST['col_id']):null;
        $return = task::GetTaskDetails($task_id);
        echo json_encode(array('type' =>'success' ,'result' =>$return ,'msg'=>'Returned Successfully'));
        return false;exit();
    break;
    case 10://add comment
        $comment = isset($_POST['comment'])?other::security($_POST['comment']):null;
        $task_id = isset($_POST['tid'])?other::security($_POST['tid']):null;
        $valid_comment = validation::ValidateValue($comment,'Comment',array('required','strings'));
        if (is_string($valid_comment)==true) {
           echo json_encode(array('type' =>'n' ,'msg'=>$valid_comment));return false;exit();
        }
        $valid_task = validation::ValidateValue($task_id,'Task',array('required','numeric'));
        if (is_string($valid_task)==true) {
           echo json_encode(array('type' =>'n' ,'msg'=>$valid_task));return false;exit();
        }
        if(!validation::is_exsist($task_id,'Task','task','id'))
        {echo json_encode(array('type' =>'n' ,'msg'=>$valid_task));return false;exit();}

        $commentobj= new comment();
        $commentobj->c_comment=$comment;$commentobj->c_task_id=$task_id;
        $commentobj->c_created=date('Y-m-d H:m:i');
        if ($commentobj->save()) {
            echo json_encode(array('type' =>'success' ,'msg'=>'Comment Saved Successfully'));return false;exit();
        }
    break;
    case 11:
        $array = isset($_POST['data'])?$_POST['data']:null;
        for ($counter=0; $counter < count($array) ; $counter++) { 
            task::UpdateOneInput($array[$counter][0],'t_sort',$array[$counter][1]);
            task::UpdateOneInput($array[$counter][0],'t_group',$array[$counter][2]);
        }
        echo json_encode(array('type' =>'success' ,'msg'=>'Sort Saved Successfully'));return false;exit();
    break;   
    case 12://node js call refresh task
        $group = isset($_POST['group'])?$_POST['group']:null;
        $result=task::GetTasks($group);
        echo json_encode(array('type' =>'success' ,'result'=>$result,'msg'=>'Tasks Returned Successfully'));return false;exit();
    break;    
    case 13://node js call refresh comments
        $task_id = isset($_POST['tid'])?$_POST['tid']:null;
        $result=comment::GetComments($task_id);
        echo json_encode(array('type' =>'success' ,'result'=>$result,'msg'=>'Tasks Returned Successfully'));return false;exit();
    break;    
}