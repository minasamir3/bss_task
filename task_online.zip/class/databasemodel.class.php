<?php

class DatabaseModel
{
    private function attributes ()
    {
        foreach($this->dbfields as $field){
            if(is_int($this->$field) || is_double($this->$field)){
                if($this->$field != null)
                $string[]=$field . " =".$this->$field ."";
            }else{
                if($this->$field != null)
            $string[]=$field . " ='".$this->$field ."'";
            }
        }
        return implode(", ",$string);
    }
    // This Main Read (Item) Function From Database 
    public static function read($sql, $type = PDO::FETCH_ASSOC, $class = null)
    {
        global $dbh;
        
        $results = $dbh->query($sql);
        if($results) {
            if(null !== $class && $type == PDO::FETCH_CLASS) {
                $data = $results->fetchAll($type, $class);
            } else {
                $data = $results->fetchAll($type);
            }
            if(count($data) == 1) {
                $data = array_shift($data);
            }
            return $data;
        } else {
            return false;
        }
    }
    // This Main Add (Item) Function In Database
    private function add()
    {
        global $dbh; // Database 1 (Primary)

            $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
                
        $sql ="INSERT INTO ". $this->tablename . " SET ".$this->attributes();
        $affectedRows = $dbh->exec($sql);
        
        if($affectedRows != false){
            $this->id =$dbh->lastInsertId();
            
        }else{
                return false;
             }
            return true;        
    }
    // This Main Update (Item) Function In Database
    private function update()
    {
        global $dbh;
        $sql ="UPDATE ". $this->tablename . " SET ".$this->attributes() . 'WHERE id= ' . $this->id;
                $affectedRows = $dbh->exec($sql);
        
        return $affectedRows !=false ? true : false;
    }
    // This Main Delete (Item) Function In Database
     public function delete ()
    {
        global $dbh;
        $sql = "DELETE FROM " . $this->tablename . ' WHERE id = ' . $this->id;
        $affectedRows = $dbh->exec($sql);
         
        return $affectedRows != false ? true : false;
    }
    // This Main save (Item) Function In Database
    public function Save()
    {
        return($this->id === null) ? $this->add() : $this->update();
    }
}