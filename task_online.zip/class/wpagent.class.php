<?php
class wpagent extends DatabaseModel {
    public $id;
    public $first_name;
    public $last_name;
    public $full_name;
    public $phone;
    public $email_google;
    public $email_facebook;
    public $email;
    public $gender;
    public $birthday;
    public $facebook_id;
    public $google_id;
    public $password;
    public $img;
    public $company;
    public $address;
    public $tablename ="wp_agents";
    public $dbfields = array(
        'id',
        'first_name',
        'last_name',
        'full_name',
        'phone',
        'email_google',
        'email_facebook',
        'email',
        'gender',
        'birthday',
        'facebook_id',
        'google_id',
        'password',
        'img',
        'company',
        'address'
    );
    public static function CheckAgent($type,$id,$email,$password){
        switch($type){
            case 2: // FaceBook Login
                $user = self::read("SELECT * FROM wp_agents WHERE facebook_id='$id'",PDO::FETCH_CLASS,__CLASS__);
                return $user->id;
                break;
            case 3: // Google Login
                $user = self::read("SELECT * FROM wp_agents WHERE google_id='$id'",PDO::FETCH_CLASS,__CLASS__);
                return $user->id;
                break;
            default: // Normal Login
                $enc_password = md5($password);
                $user = self::read("SELECT * FROM wp_agents WHERE email LIKE '$email' AND password LIKE '$enc_password'",PDO::FETCH_CLASS,__CLASS__);
                if($user !=null && $user !=0){
                    return $user->id;
                }else{
                    $user = self::read("SELECT * FROM wp_agents WHERE (email LIKE '$email' AND (password =0 OR password IS NULL) ) LIMIT 1",PDO::FETCH_CLASS,__CLASS__);
                    if($user !=null){
                        $user->password = $enc_password;
                        $user->save();
                        return $user->id;
                    }
                }
        }
        return 0;
    }
    
    public static function CheckEmailPhone($email,$phone){
        $user = self::read("SELECT * FROM wp_agents WHERE email='$email' OR phone = '$phone'",PDO::FETCH_CLASS,__CLASS__);
        if($user !=null)
            return $user->id;
        return false;
    }
    
    public static function GetPhone($agent_id){
        $get = self::read("SELECT phone FROM wp_agents WHERE id=$agent_id",PDO::FETCH_CLASS,__CLASS__);
        return $get->phone;
    }
    public static function GetName($agent_id){
        $get = self::read("SELECT first_name,last_name FROM wp_agents WHERE id=$agent_id",PDO::FETCH_CLASS,__CLASS__);
        return $get->first_name.' '.$get->last_name;
    }
}