<?php
class contact extends DatabaseModel {
    public $id;
    public $name;
    public $phone;
    public $communication_type;
    public $email;
    public $notes;
    public $type;
    public $tablename ="contact";
    public $dbfields = array(
        'id',
        'name',
        'phone',
        'communication_type',
        'email',
        'notes',
        'type'
    );
}