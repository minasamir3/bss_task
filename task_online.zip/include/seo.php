<?php $mainsetting = DatabaseModel::read("SELECT * FROM pages WHERE id=1",PDO::FETCH_CLASS,'DatabaseModel'); ?>
    <!-- Main Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name='language' content='Arabic'>
    <meta name='Author' content='Elmalek Cars'>
    <meta name='revisit-after' content='1 day'>
    <link rel="alternate" hreflang="ar-eg" href="<?php echo URL; ?>">
    <link rel="canonical" href="<?php echo URL; ?>">
    <?php if(strpos(URL, 'fb_comment_id')) { echo '<meta name="robots" content="noindex, nofollow">';} ?>
    <!-- Icons Logo -->
    <link href="<?php echo IMG_DIR.'icon.png' ?>" rel="icon">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- Google verification -->
    <meta name="google-site-verification" content="<?php echo $mainsetting->google_ver ?>" />
    <!-- Google Analytics -->
    <script>
        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o)
                , m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
        ga('create', '<?php echo $mainsetting->google_anl ?>', 'auto');
        ga('send', 'pageview');
    </script>
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', '<?php echo $mainsetting->google_anl ?>']);
  _gaq.push(['_trackPageview']);
  setTimeout("_gaq.push(['_trackEvent', '15_seconds', 'read'])",15000);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
    <!-- Bing Verification -->
    <meta name="msvalidate.01" content="<?php  echo $mainsetting->bing_ver; ?>" />
    <!-- Alexa Verification -->
    <meta name="alexaVerifyID" content="<?php  echo $mainsetting->alexa_ver; ?>" />
    <!-- pinterest Verification -->
    <meta name="p:domain_verify" content="<?php echo $mainsetting->pinterest_ver ?>" />
<?php
    if(basename($_SERVER["SCRIPT_FILENAME"]) == 'index.php'){ ?>
<title><?php echo $mainsetting->main_title; ?></title>

<meta name="description" content="<?php echo $mainsetting->main_description; ?>">

<meta name="keywords" content="<?php echo $mainsetting->keywords; ?>">

<meta property="og:title" content="<?php if($mainsetting->fb_title != null) echo $mainsetting->fb_title; else echo $mainsetting->main_title; ?>">

<meta property="og:description" content="<?php if($mainsetting->fb_description != null) echo $mainsetting->fb_description; else echo $mainsetting->main_description; ?>">

<meta property="og:url" content="<?php echo URL; ?>">

<meta property="og:image" content="<?php echo UPLOADS_DIR.$mainsetting->fb_image; ?>">

<meta property="og:type" content="website">

<meta name="twitter:card" content="summary" />

<meta name="twitter:site" content="@ElMalekcars" />

<meta name="twitter:title" content="<?php if($mainsetting->twitter_title != null) echo $mainsetting->twitter_title; else if($mainsetting->fb_title != null) echo $mainsetting->fb_title; else echo $mainsetting->main_title; ?>" />

<meta name="twitter:description" content="<?php if($mainsetting->twitter_description != null) echo $mainsetting->twitter_description; else if($mainsetting->fb_description != null) echo $mainsetting->fb_description; else echo $mainsetting->main_description; ?>" />
<meta name="twitter:image" content="<?php if($mainsetting->twitter_image == null) echo UPLOADS_DIR.$mainsetting->twitter_image; else echo UPLOADS_DIR.$mainsetting->fb_image ?>" />
<?php
    }
    elseif(pages::CheckPageLink($_SERVER['REQUEST_URI'])!=0 || pages::CheckPageLink(basename($_SERVER["SCRIPT_FILENAME"]))!=0){
        if(pages::CheckPageLink($_SERVER['REQUEST_URI']))
            $pageid = pages::CheckPageLink($_SERVER['REQUEST_URI']);
        else
            $pageid=pages::CheckPageLink(basename($_SERVER["SCRIPT_FILENAME"]));
        $pages = DatabaseModel::read("SELECT * FROM pages WHERE id=$pageid",PDO::FETCH_CLASS,'DatabaseModel');
?>
<title><?php echo $pages->main_title; ?></title>

<meta name="description" content="<?php echo $pages->main_description; ?>">

<meta name="keywords" content="<?php echo $pages->keywords; ?>">

<meta property="og:title" content="<?php if($pages->fb_title != null) echo $pages->fb_title; else echo $pages->main_title; ?>">

<meta property="og:description" content="<?php if($pages->fb_description != null) echo $pages->fb_description; else echo $pages->main_description; ?>">

<meta property="og:url" content="<?php echo URL; ?>">

<meta property="og:image" content="<?php echo UPLOADS_DIR.$pages->fb_image; ?>">

<meta property="og:type" content="website">

<meta name="twitter:card" content="summary" />

<meta name="twitter:site" content="@ElMalekcars" />

<meta name="twitter:title" content="<?php if($pages->twitter_title != null) echo $pages->twitter_title; else if($pages->fb_title != null) echo $pages->fb_title; else echo $pages->main_title; ?>" />

<meta name="twitter:description" content="<?php if($pages->twitter_description != null) echo $pages->twitter_description; else if($pages->fb_description != null) echo $pages->fb_description; else echo $pages->main_description; ?>" />

<meta name="twitter:image" content="<?php if($pages->twitter_image == null) echo UPLOADS_DIR.$pages->twitter_image; else echo UPLOADS_DIR.$pages->fb_image ?>" />
<?php 
    }
    elseif($cars !=null && basename($_SERVER["SCRIPT_FILENAME"]) != 'compare.php'){
if($typebrand == 1){
echo '<script>console.log("'.$cars.'")</script>'; 
    $brand = DatabaseModel::read("SELECT * FROM brands WHERE UPPER(title_en) LIKE UPPER('$brandid') LIMIT 1",PDO::FETCH_CLASS,'brands');
    $carmodel = DatabaseModel::read("SELECT id FROM carsmodel WHERE brand_id=$brand->id AND UPPER(title_en) LIKE UPPER('$modelid') LIMIT 1", PDO::FETCH_CLASS,'carsmodel');
    if($brand !=null) 
    $car = DatabaseModel::read("SELECT * FROM cars WHERE (UPPER(title_en) LIKE UPPER('$cars') or id = '$cars') AND carmodel_id=$carmodel->id AND brand_id=$brand->id LIMIT 1",PDO::FETCH_CLASS,'cars');
    if($car !=null){ 
        $image = DatabaseModel::read("SELECT mainimage FROM photocar WHERE carmodel_id=$carmodel->id LIMIT 1",PDO::FETCH_CLASS,'DatabaseModel');

?>
<title dir="rtl"><?php echo $car->title.' - الملك للسيارات'; ?></title>
    <meta name="description" content="<?php echo $car->description; ?>">

    <meta name="keywords" content="<?php echo $car->keywords; ?>">

    <meta property="og:title" content="<?php echo $car->title; ?>">

    <meta property="og:description" content="<?php echo $car->description; ?>">

    <meta property="og:url" content="<?php echo URL; ?>">

    <meta property="og:image" content="<?php echo UPLOADS_DIR.$car->socialimage; ?>">

    <meta property="og:type" content="website">

    <meta name="twitter:card" content="summary" />

    <meta name="twitter:site" content="@ElMalekcars" />

    <meta name="twitter:title" content="<?php echo $car->title; ?>" />

    <meta name="twitter:description" content="<?php echo $car->description; ?>" />

    <meta name="twitter:image" content="<?php echo UPLOADS_DIR.$car->socialimage; ?>" />
<script type="application/ld+json">
{
  "@context": "http://schema.org/",
  "@type": "Product",
  "name": "<?php echo $car->title ?>",
  "image": "<?php echo UPLOADS_DIR.$image->mainimage; ?>",
  "description": "<?php echo $car->description ?>",
  "brand": {
    "@type": "Car",
    "name": "<?php echo $brand->title_ar; ?>"
  },
  "offers": {
    "@type": "Offer",
    "priceCurrency": "EGP",
    "price": "<?php echo $car->web_price; ?>",
    "priceValidUntil": "<?php
        $datess = strtotime($car->timeprice);
        $datess = strtotime("+7 day", $date);
        echo date('Y-m-d', $datess); ?>",
    "availability": "<?php echo URL; ?>",
    "seller": {
      "@type": "Organization",
      "name": "Elmalek Cars"
    }
  }
}
</script>
<?php   
                   }
}
elseif($typebrand == 2){
    $brand = DatabaseModel::read("SELECT * FROM brandskh WHERE UPPER(title_en) LIKE UPPER('$brandid') LIMIT 1",PDO::FETCH_CLASS,'brandskh');
    $carmodel = DatabaseModel::read("SELECT id FROM carsmodelkh WHERE brand_id=$brand->id AND UPPER(title_en) LIKE UPPER('$modelid') LIMIT 1", PDO::FETCH_CLASS,'carsmodel');
    if($brand !=null)
    $car = DatabaseModel::read("SELECT * FROM carskh WHERE id = '$cars' OR title_en LIKE '$cars' AND carmodel_id=$carmodel->id AND brand_id=$brand->id LIMIT 1",PDO::FETCH_CLASS,'carskh');
    if($car !=null){
        $image = DatabaseModel::read("SELECT mainimage FROM photocarkh WHERE carmodel_id=$carmodel->id LIMIT 1",PDO::FETCH_CLASS,'DatabaseModel');
?>
<title><?php echo $car->title.' - الملك للسيارات'; ?></title>
    <meta name="description" content="<?php echo $car->description; ?>">

    <meta name="keywords" content="<?php echo $car->keywords; ?>">

    <meta property="og:title" content="<?php echo $car->title; ?>">

    <meta property="og:description" content="<?php echo $car->description; ?>">

    <meta property="og:url" content="<?php echo URL; ?>">

    <meta property="og:image" content="<?php echo UPLOADS_DIR.$mainsetting->fb_image; ?>">

    <meta property="og:type" content="website">

    <meta name="twitter:card" content="summary" />

    <meta name="twitter:site" content="@ElMalekcars" />

    <meta name="twitter:title" content="<?php echo $car->title; ?>" />

    <meta name="twitter:description" content="<?php echo $car->description; ?>" />

    <meta name="twitter:image" content="<?php echo UPLOADS_DIR.$mainsetting->twitter_image; ?>" />
<script type="application/ld+json">
{
  "@context": "http://schema.org/",
  "@type": "Product",
  "name": "<?php echo $car->title ?>",
  "image": "<?php echo UPLOADS_DIR.$image->mainimage; ?>",
  "description": "<?php echo $car->description ?>",
  "brand": {
    "@type": "Car",
    "name": "<?php echo $brand->title_ar; ?>"
  },
  "offers": {
    "@type": "Offer",
    "priceCurrency": "EGP",
    "price": "<?php echo $car->web_price; ?>",
    "priceValidUntil": "<?php
        $datess = strtotime($car->timeprice);
        $datess = strtotime("+7 day", $date);
        echo date('Y-m-d', $datess); ?>",
    "availability": "<?php echo URL; ?>",
    "seller": {
      "@type": "Organization",
      "name": "Elmalek Cars"
    }
  }
}
</script>
<?php   
                   }
}
}
    elseif($modelid !=null){
     if($typebrand == 1){
        $brand = DatabaseModel::read("SELECT * FROM brands WHERE UPPER(title_en) LIKE UPPER('$brandid') LIMIT 1",PDO::FETCH_CLASS,'brands'); 
        if($brand !=null)
        $model = DatabaseModel::read("SELECT * FROM carsmodel WHERE UPPER(title_en) LIKE UPPER('$modelid') AND brand_id=$brand->id",PDO::FETCH_CLASS,'carsmodel');

        if($model !=null){  ?>
    <title><?php echo $model->title; ?> - الملك للسيارات</title>
    <meta name="description" content="<?php echo $model->description; ?>">

    <meta name="keywords" content="<?php echo $model->keywords; ?>">

    <meta property="og:title" content="<?php echo $model->title_ar; ?>">

    <meta property="og:description" content="<?php echo $model->description; ?>">

    <meta property="og:url" content="<?php echo URL; ?>">

    <meta property="og:image" content="<?php echo UPLOADS_DIR.$mainsetting->fb_image; ?>">

    <meta property="og:type" content="website">

    <meta name="twitter:card" content="summary" />

    <meta name="twitter:site" content="@ElMalekcars" />

    <meta name="twitter:title" content="<?php echo $model->title_ar; ?>" />

    <meta name="twitter:description" content="<?php echo $model->description; ?>" />

    <meta name="twitter:image" content="<?php echo UPLOADS_DIR.$mainsetting->twitter_image; ?>" />
    <?php  ;
                       }
 }
    elseif($typebrand == 2){
    $brand = DatabaseModel::read("SELECT * FROM brandskh WHERE UPPER(title_en) LIKE UPPER('%$brandid%') LIMIT 1",PDO::FETCH_CLASS,'brands');
    if($brand !=null)
        $model = DatabaseModel::read("SELECT * FROM carsmodelkh WHERE UPPER(title_en) LIKE UPPER('$modelid') AND brand_id=$brand->id",PDO::FETCH_CLASS,'carsmodel');
    if($model !=null){ ?>
<title><?php echo $model->title; ?> - الملك للسيارات</title>
<meta name="description" content="<?php echo $model->description; ?>">

<meta name="keywords" content="<?php echo $model->keywords; ?>">

<meta property="og:title" content="<?php echo $model->title; ?> - الملك للسيارات">

<meta property="og:description" content="<?php echo $model->description; ?>">

<meta property="og:url" content="<?php echo URL; ?>">

<meta property="og:image" content="<?php echo UPLOADS_DIR.$mainsetting->fb_image; ?>">

<meta property="og:type" content="website">

<meta name="twitter:card" content="summary" />

<meta name="twitter:site" content="@ElMalekcars" />

<meta name="twitter:title" content="<?php echo $model->title; ?>" />

<meta name="twitter:description" content="<?php echo $model->description; ?>" />

<meta name="twitter:image" content="<?php echo UPLOADS_DIR.$mainsetting->twitter_image; ?>" />
<?php   
                   }
}
}
    elseif($brandid !=null && basename($_SERVER["SCRIPT_FILENAME"]) != 'compare.php'){
         if($typebrand == 1){
            $brand = DatabaseModel::read("SELECT * FROM brands WHERE UPPER(title_en) LIKE UPPER('%$brandid%') LIMIT 1",PDO::FETCH_CLASS,'brands'); 
            if($brand !=null){  ?>
<title><?php echo $brand->title; ?> - الملك للسيارات</title>
<meta name="description" content="<?php echo $brand->description; ?>">

<meta name="keywords" content="<?php echo $brand->keywords; ?>">

<meta property="og:title" content="<?php echo $brand->title; ?> - الملك للسيارات">

<meta property="og:description" content="<?php echo $brand->description; ?>">

<meta property="og:url" content="<?php echo URL; ?>">

<meta property="og:image" content="<?php echo UPLOADS_DIR.$mainsetting->fb_image; ?>">

<meta property="og:type" content="website">

<meta name="twitter:card" content="summary" />

<meta name="twitter:site" content="@ElMalekcars" />

<meta name="twitter:title" content="<?php echo $brand->title; ?> - الملك للسيارات" />

<meta name="twitter:description" content="<?php echo $brand->description; ?>" />

<meta name="twitter:image" content="<?php echo UPLOADS_DIR.$mainsetting->twitter_image; ?>" />
<?php  ;
                           }
        }
        elseif($typebrand == 2){
            $brand = DatabaseModel::read("SELECT * FROM brandskh WHERE UPPER(title_en) LIKE UPPER('%$brandid%') LIMIT 1",PDO::FETCH_CLASS,'brands');
                        if($brand !=null){  ?>
<title><?php echo $brand->title; ?> - الملك للسيارات</title>
<meta name="description" content="<?php echo $brand->description; ?>">

<meta name="keywords" content="<?php echo $brand->keywords; ?>">

<meta property="og:title" content="<?php echo $brand->title; ?> - الملك للسيارات">

<meta property="og:description" content="<?php echo $brand->description; ?>">

<meta property="og:url" content="<?php echo URL; ?>">

<meta property="og:image" content="<?php echo UPLOADS_DIR.$mainsetting->fb_image; ?>">

<meta property="og:type" content="website">

<meta name="twitter:card" content="summary" />

<meta name="twitter:site" content="@ElMalekcars" />

<meta name="twitter:title" content="<?php echo $brand->title; ?> - الملك للسيارات" />

<meta name="twitter:description" content="<?php echo $brand->description; ?>" />

<meta name="twitter:image" content="<?php echo UPLOADS_DIR.$mainsetting->twitter_image; ?>" />
<?php  ;
                           }
        }
    }
    elseif(basename($_SERVER["SCRIPT_FILENAME"]) == 'compare.php'){
$carid1 =0;
$typebrand1 = 1;
$brandid1 =  0;
$carmodelid1 =  0;
$carid2 =0;
$typebrand2 = 1;
$brandid2 =  0;
$carmodelid2 =  0;
$typebrand3 =  1;
$brandid3 =  0;
$carmodelid3 =  0;
$carid3 =  0;

$typebrand4 =  1;
$brandid4 = 0;
$carmodelid4 =  0;
$carid4 =  0;
$json = '[]';
if(isset($_COOKIE['compare'])){
$json= $_COOKIE['compare'];
}
    $array =json_decode($json);
if(isset($_POST['typebrand1'])){
 $typebrand1 = isset($_POST['typebrand1']) ? other::security($_POST['typebrand1']) : 1;
$brandid1 = isset($_POST['brandid1']) ? other::security($_POST['brandid1']) : 0;
$carmodelid1 = isset($_POST['carmodelid1']) ? other::security($_POST['carmodelid1']) : 0;
$carid1 = isset($_POST['carid1']) ? other::security($_POST['carid1']) : 0;

$typebrand2 = isset($_POST['typebrand2']) ? other::security($_POST['typebrand2']) : 1;
$brandid2 = isset($_POST['brandid2']) ? other::security($_POST['brandid2']) : 0;
$carmodelid2 = isset($_POST['carmodelid2']) ? other::security($_POST['carmodelid2']) : 0;
$carid2 = isset($_POST['carid2']) ? other::security($_POST['carid2']) : 0;

$typebrand3 = isset($_POST['typebrand3']) ? other::security($_POST['typebrand3']) : 1;
$brandid3 = isset($_POST['brandid3']) ? other::security($_POST['brandid3']) : 0;
$carmodelid3 = isset($_POST['carmodelid3']) ? other::security($_POST['carmodelid3']) : 0;
$carid3 = isset($_POST['carid3']) ? other::security($_POST['carid3']) : 0;

$typebrand4 = isset($_POST['typebrand4']) ? other::security($_POST['typebrand4']) : 1;
$brandid4 = isset($_POST['brandid4']) ? other::security($_POST['brandid4']) : 0;
$carmodelid4 = isset($_POST['carmodelid4']) ? other::security($_POST['carmodelid4']) : 0;
$carid4 = isset($_POST['carid4']) ? other::security($_POST['carid4']) : 0;
   
}
elseif(isset($_GET['car'])){
    $car = other::security($_GET['car']);
    $car = latestcompare::read("SELECT * FROM latest_compare WHERE url LIKE '$car'",PDO::FETCH_CLASS,'latestcompare');
    if($car !=null){
        $carid1 = $car->carid1;
        $typebrand1 = $car->typebrand1;
        $brandid1 = $car->brandid1;
        $carmodelid1 = $car->carmodel1;
        $carid2 = $car->carid2;
        $typebrand2 = $car->typebrand2;
        $brandid2 = $car->brandid2;
        $carmodelid2 = $car->carmodel2; 
    }
}
elseif($array !=null){
     $json= $_COOKIE['compare'];
     $array =json_decode($json);
     if(is_object($array)){
        $typebrand1 = $array[1];
        $brandid1 = $array[3];
        $carmodelid1 = $array[2];
        $carid1 = $array[0];
     }else{
         $i=1;
         foreach($array as $array){
             if($i == 1){
                 $typebrand1 = $array[1];
                 $brandid1 = $array[3];
                 $carmodelid1 = $array[2];
                 $carid1 = $array[0];
             }
             elseif($i == 2){
                 $typebrand2 = $array[1];
                 $brandid2 = $array[3];
                 $carmodelid2 = $array[2];
                 $carid2 = $array[0]; 
             }
             elseif($i == 3){
                 $typebrand3 = $array[1];
                 $brandid3 = $array[3];
                 $carmodelid3 = $array[2];
                 $carid3 = $array[0];
             }
             elseif($i == 4){
                 $typebrand4 = $array[1];
                 $brandid4 = $array[3];
                 $carmodelid4 = $array[2];
                 $carid4 = $array[0];
             }
             $i++;
             
         }
     }
 }
else{ 
$typebrand1 = isset($_POST['typebrand1']) ? other::security($_POST['typebrand1']) : 1;
$brandid1 = isset($_POST['brandid1']) ? other::security($_POST['brandid1']) : 0;
$carmodelid1 = isset($_POST['carmodelid1']) ? other::security($_POST['carmodelid1']) : 0;
$carid1 = isset($_POST['carid1']) ? other::security($_POST['carid1']) : 0;

$typebrand2 = isset($_POST['typebrand2']) ? other::security($_POST['typebrand2']) : 1;
$brandid2 = isset($_POST['brandid2']) ? other::security($_POST['brandid2']) : 0;
$carmodelid2 = isset($_POST['carmodelid2']) ? other::security($_POST['carmodelid2']) : 0;
$carid2 = isset($_POST['carid2']) ? other::security($_POST['carid2']) : 0;

$typebrand3 = isset($_POST['typebrand3']) ? other::security($_POST['typebrand3']) : 1;
$brandid3 = isset($_POST['brandid3']) ? other::security($_POST['brandid3']) : 0;
$carmodelid3 = isset($_POST['carmodelid3']) ? other::security($_POST['carmodelid3']) : 0;
$carid3 = isset($_POST['carid3']) ? other::security($_POST['carid3']) : 0;

$typebrand4 = isset($_POST['typebrand4']) ? other::security($_POST['typebrand4']) : 1;
$brandid4 = isset($_POST['brandid4']) ? other::security($_POST['brandid4']) : 0;
$carmodelid4 = isset($_POST['carmodelid4']) ? other::security($_POST['carmodelid4']) : 0;
$carid4 = isset($_POST['carid4']) ? other::security($_POST['carid4']) : 0;
}
if($carid1 !=0 && $carid2 !=0){
    if(latestcompare::checkCars($carid1,$carid2)){ 
        $latest = new latestcompare();
        $latest->carid1 = $carid1;
        $latest->typebrand1 = $typebrand1;
        $latest->brandid1 = $brandid1;
        $latest->carmodel1 = $carmodelid1;
        $latest->carid2 = $carid2;
        $latest->typebrand2 = $typebrand2;
        $latest->brandid2 = $brandid2;
        $latest->carmodel2 = $carmodelid2;
        $latest->view = 1;
        if($typebrand1 == 1 && $typebrand2 == 1){
            $car1=cars::getTitleEn($carid1);
            $car2=cars::getTitleEn($carid2);
            if($car1 !=null && $car2 !=null){
                $latest->url = $car1.'-vs-'.$car2;
                $latest->save();
            }
        }
        elseif($typebrand1 == 1 && $typebrand2 == 2){
            $car1=cars::getTitleEn($carid1);
            $car2=carskh::getTitleEn($carid2);
            if($car1 !=null && $car2 !=null){
                $latest->url = $car1.'-vs-'.$car2;
                $latest->save();
            }
        }
        elseif($typebrand1 == 2 && $typebrand2 == 1){
            $car1=carskh::getTitleEn($carid1);
            $car2=cars::getTitleEn($carid2);
            if($car1 !=null && $car2 !=null){
                $latest->url = $car1.'-vs-'.$car2;
                $latest->save();
            }
        }
        elseif($typebrand1 == 2 && $typebrand2 == 2){
            $car1=carskh::getTitleEn($carid1);
            $car2=carskh::getTitleEn($carid2);
            if($car1 !=null && $car2 !=null){
                $latest->url = $car1.'-vs-'.$car2;
                $latest->save();
            }
        }
    }
}
        $car_1 = cars::getTitle($carid1,$typebrand1);
        $car_2 = cars::getTitle($carid2,$typebrand2);
        $title = 'مقارنة بين  '.$car_1.' و '.$car_2. ' - الملك للسيارات';
?>
<title><?php echo $title ?></title>
<meta name="description" content="<?php echo $title ?>">

<meta name="keywords" content="<?php echo cars::getTitle($carid1,$typebrand1).','.cars::getTitle($carid2,$typebrand2) ?>">

<meta property="og:title" content="<?php echo $title ?>">

<meta property="og:description" content="<?php echo $title; ?>">

<meta property="og:url" content="<?php echo WEBSITE.DS.'ar'.DS.'comparecars'.DS.$car->url; ?>">

<meta property="og:image" content="<?php echo UPLOADS_DIR.$mainsetting->fb_image; ?>">

<meta property="og:type" content="website">

<meta name="twitter:card" content="summary" />

<meta name="twitter:site" content="@ElMalekcars" />

<meta name="twitter:title" content="<?php echo $title; ?> - الملك للسيارات" />

<meta name="twitter:description" content="<?php echo $title; ?>" />

<?php
    }
?>
<!-- Schema Tags -->
<script type="application/ld+json"> 
{
"@context": "https://schema.org",
"@type": "Organization",
"url": "https://www.elmalekcars.com.eg/ar/",
"logo": "https://www.elmalekcars.com.eg/assets/img/website.png" 
}
</script>
<script type="application/ld+json">
{ 
"@context" : "https://schema.org",
"@type" : "Organization",
"url" : "https://www.elmalekcars.com.eg/ar/",
"contactPoint" : [ 
    {
    "@type" : "ContactPoint",
    "telephone" : "+201021022222",
    "contactType" : "customer service"
    } 
    ]
}
</script>
<script type="application/ld+json"> 
{ 
"@context" : "https://schema.org",
"@type" : "Organization",
"name" : "ُEl-MalekCars",
"url" : "https://www.elmalekcars.com.eg/ar/",
"sameAs" : 
    [
    "<?php echo $mainsetting->facebook; ?>",
    "<?php echo $mainsetting->twitter; ?>",
    "<?php echo $mainsetting->instagram; ?>",
    "<?php echo $mainsetting->googleplus; ?>",
    "<?php echo $mainsetting->youtube; ?>"
    ]
}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "AutomotiveBusiness",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Cairo",
    "addressRegion": "EG",
    "postalCode": "11475",
    "streetAddress": "60 El-Nozha, Almazah, Heliopolis , Cairo, Egypt"
  },
  "name": "Elmalek Cars",
  "openingHours": "Sa-Fr 10:00-23:00",
  "telephone": "(+20) 01021022222",
  "url": "https://www.elmalekcars.com.eg/ar/",
  "image": "https://www.elmalekcars.com.eg/uploads/<?php echo $mainsetting->fb_image; ?>",
  "priceRange":"$$"
}
</script>