    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-M6QHJJJ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<header class="container-fluid">
    <div class="nopadding col-lg-9 col-md-12 col-sm-12 col-xs-12">
        <div class="social-icons  pull-left col-lg-4 col-md-5 col-sm-5 col-xs-12">
            <a href="<?php echo $mainsetting->facebook; ?>"><i class="fa fa-facebook "></i></a>
            <a href="<?php echo $mainsetting->linkedin; ?>"><i class="fa fa-linkedin "></i></a>
            <a href="<?php echo $mainsetting->instagram; ?>"><i class="fa fa-instagram "></i></a>
            <a href="<?php echo $mainsetting->twitter; ?>"><i class="fa fa-twitter "></i></a>
            <a href="<?php echo $mainsetting->youtube; ?>"><i class="fa fa-youtube-play "></i></a>
            <a href="<?php echo $mainsetting->googleplus; ?>"><i class="fa fa-google-plus "></i></a> 
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 hidden-xs pull-right ">
            <p class="pull-right signature">الملك للسيارات ارخص سعر فى مصر.. ثقة تدوم لسنوات</p>
        </div>
        <br /> </br>
        <hr class="header-bar hidden-xs" /> </div>
<div class="header-logo nopadding col-lg-3 col-md-12 col-sm-12 col-xs-12 pull-right">
        <a href="<?php echo HOST_NAME ?>">
            <img class="img-responsive" src="<?php echo HOST_NAME ?>/assets/img/website.png?ver=0" alt="Elmalek Cars" title="Elmalek Cars">
        </a>
</div>
    <div class="nav-header nopadding col-lg-9 col-md-12 col-sm-12 col-xs-12 pull-left">
        <nav class="navbar navbar-custom">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#Navbar"> <span class="icon-bar"> </span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                </div>
                <div class="collapse navbar-collapse" id="Navbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li><span class="hidden-sm hidden-xs"> | &nbsp;</span><a href="<?php echo HOST_NAME.DS.'ar'.DS ;?>">  الصفحة الرئيسية <i class="fa fa-home"></i></a></li>
                        <li><span class="hidden-sm hidden-xs"> | &nbsp;</span><a href="<?php echo HOST_NAME.DS.'ar'.DS.'models/' ?>"> سيارات جديدة <i class="fa fa-car"></i></a></li>
                        <li><span class="hidden-sm hidden-xs"> | &nbsp;</span><a href="<?php echo HOST_NAME.DS.'used-cars'.DS ?>"> سيارات مستعملة <i class="fa fa-car"></i></a></li>
                        <?php if(isset($user) && $user !=null){ ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="caret"></span> <?php echo $user->first_name; ?> </a>
                            <ul class="dropdown-menu">
                                <li><a href="/used-cars/profile.php">حسابى</a></li>
                                <li><a href="/used-cars/logout.php">تسجيل خروج</a></li>
                            </ul>
                          </li>
                        <?php }else{ ?>
                        <li><a href="<?php echo HOST_NAME.DS.'used-cars'.DS.'login.php'; ?>">تسجيل دخول <i class="fa fa-sign-in"></i></a></li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</header>