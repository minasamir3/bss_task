
<footer class="container-fluid">'
    <div class="col-xs-12 col-sm-12 text-center" style="overflow:hidden;margin-bottom:20px">
    <?php echo sidebar::show(5); ?>
    </div>
<div class="col-md-4 col-xs-12 pull-right ">
    <img class="footer-logo img-responsive" src="/assets/img/logo-gray.png" alt="Elmalek Cars" title="Elmalek Cars">
    <div class="socialiconss col-lg-12 col-sm-12 col-xs-12 text-center">
        <a href="<?php echo $mainsetting->facebook; ?>" target="_blank"><i class="fa fa-facebook "></i></a>
            <a href="<?php echo $mainsetting->linkedin; ?>" target="_blank"><i class="fa fa-linkedin "></i></a>
            <a href="<?php echo $mainsetting->instagram; ?>" target="_blank"><i class="fa fa-instagram "></i></a>
            <a href="<?php echo $mainsetting->twitter; ?>" target="_blank"><i class="fa fa-twitter "></i></a>
            <a href="<?php echo $mainsetting->youtube; ?>" target="_blank"><i class="fa fa-youtube-play "></i></a>
            <a href="<?php echo $mainsetting->googleplus; ?>" target="_blank"><i class="fa fa-google-plus "></i></a> 
    </div>
</div>
<div class="col-md-4 col-xs-12 pull-right text-right nopadding">
    <p class="row-heading">حمل تطبيق الملك</p>
    <div class="download-app col-xs-12">
        <a class="col-xs-6 border" href="//itunes.apple.com/us/app/almlk-llsyarat/id1166006751?ls=1&mt=8"><img class="img-responsive" src="/assets/img/icon-footer-appstore.png" alt="Elmalek Cars APP Store" title="Elmalek Cars APP Store"></a>
        <a class="col-xs-6" href="//play.google.com/store/apps/details?id=com.cars.elmalek.mohamed.elmalek"><img class="img-responsive" src="/assets/img/icon-footer-googleplay.png" alt="Elmalek Cars Google Play" title="Elmalek Cars Google Play"></a>
    </div>
    <div class="footer-links col-xs-12">
        <p class="row-heading">روابط قد تهمك</p>
        <a class="col-md-4 col-sm-6 col-xs-12 pull-right" href="/ar/privacy/">سياسة الخصوصية  <i class="fa fa-play"></i></a>
        <a class="col-md-4 col-sm-6 col-xs-12 pull-right" href="/ar/terms/">شروط الاستخدام <i class="fa fa-play"></i></a>
        <a class="col-md-4 col-sm-6 col-xs-12 pull-right" href="/ar/aboutus/">من نحن <i class="fa fa-play"></i></a>
        <a class="col-md-4 col-sm-6 col-xs-12 pull-right" href="/ar/contactus/">اتصل بنا <i class="fa fa-play"></i></a>
        <a class="col-md-4 col-sm-6 col-xs-12 pull-right" href="/ar/jobs/">الوظائف <i class="fa fa-play"></i></a>
        <a class="col-md-4 col-sm-6 col-xs-12 pull-right" href="http://elmalekcars.com.eg/blog/">مدونة الملك <i class="fa fa-play"></i></a>
        <a class="col-md-4 col-sm-6 col-xs-12 pull-right" href="/ar/offers/"> احدث العروض <i class="fa fa-play"></i></a>
        <a class="col-md-4 col-sm-6 col-xs-12 pull-right" href="/ar/complains/"> للشكاوى و المقترحات <i class="fa fa-play"></i></a>
    </div>
</div>
<div class="col-md-4 col-xs-12 pull-right text-right">
    <p class="row-heading">العنوان</p>
    <iframe
  frameborder="0"
  src="https://www.google.com/maps/embed/v1/place?key=AIzaSyC_QapAcDgZB6VXiLMiBXK6jUzS0XmYY64&q=Elmalek+cars+الملك+للسيارات" allowfullscreen>
</iframe>
    <span class="address"><i class="fa fa-map-marker"></i> 60 شارع النزهة - السبع عمارات - مصر الجديدة <a href="tel:01021022222"><i class="fa fa-phone"></i> 01021022222 </a> </span>
</div>
<div class="col-xs-12 copyrights text-center">
    <a dir="rtl">الموقع يتم تطويرة و إدارته بواسطة Elmalek</a>
</div>
</footer>
   <div class="compare-bar">
       <div id="carsCompare" class="col-xs-12">       
       </div>
   </div>

<div id="comapre-error1" class="modal fade bd-example-modal-md" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" dir="rtl">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-body">
        <p class="text-center heading-compare-error">تحذير</p>
        <hr>
        <p class="text-right">
            تحتوى المقارانات الخاصة بك على سياراتين، عليك حذف احداهما لإضافة سيارة جديدة
        </p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary pull-left" data-dismiss="modal">إغلاق</button>
        <button type="button" class="btn btn-danger pull-left">قارن الأن</button>
      </div>
    </div>
    
  </div>
</div>
   
   
   
   
<?php $template->setFooter(); ?>
<script type="text/javascript" src="/used-cars/assets/js\jquery-2.2.0.min.js"></script>
<script type="text/javascript" src="/used-cars/assets/js\bootstrap.min.js"></script>
<script type="text/javascript" src="/used-cars/assets/js\bootstrap-slider.js"></script>
<script type="text/javascript" src="/used-cars/assets/js\wow.min.js"></script>
<script type="text/javascript" src="/used-cars/assets/js\jquery.scrollUp.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.2/js/bootstrap-select.min.js"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script type="text/javascript" src="/used-cars/assets/js\ie10-viewport-bug-workaround.js"></script>

<!-- Custom javascript -->
<script type="text/javascript" src="/used-cars/assets/js\app.js"></script>

<!-- NoFollow for external links -->
    <script type="text/javascript">
        jQuery(document).ready(function () {
            jQuery('a[href*="https://"]:not([href*="https://www.elmalekcars.com.eg"])').attr('rel', 'nofollow');
        });
    </script>
<script type="text/javascript">var switchTo5x=true;</script>
<script type="text/javascript">stLight.options({publisher: "e02baa3f-2616-41b5-afff-367ae60d1720", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>


<script>
    
function checkLoginState() {
  FB.login(function(response) {
    if (response.authResponse) {
     FB.api('/me', 'GET',
      {"fields":"id,name,email"},
      function(response) {
         $.ajax({
            type: "POST"
            , url: "/used-cars/login.php"
            , data: {
                'name': response.name,
                'facebook_id' : response.id,
                'email' : response.email
            }
            , dataType: "json"
            , success: function (data) {
                
            }
        });
      }
    );
    window.location.href = 'https://elmalekcars.com.eg/used-cars/';
    } else {
     console.log('User cancelled login or did not fully authorize.');
    }
}, {scope: 'email,user_likes'});
}
</script>
</html>