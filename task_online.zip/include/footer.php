
</div>

<!-- Javascript -->
<script src="assets/bundles/libscripts.bundle.js"></script>    
<script src="assets/bundles/vendorscripts.bundle.js"></script>

<script src="assets/vendor/nestable/jquery.nestable.js?ver=1.0s002s"></script> <!-- Jquery Nestable -->

<script src="assets/bundles/mainscripts.bundle.js"></script>
<script src="assets/js/pages/ui/sortable-nestable.js?ver=1.0002ss"></script> 
<script src="node_modules/socket.io/node_modules/socket.io-client/socket.io.js"></script> 
<script src="assets/js/main.js"></script>

</body>
</html>
