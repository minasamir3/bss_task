<?php require_once('../config.php');
// Set Session
$session= isset($_SESSION['login_user']) ? $_SESSION['login_user'] : null;
if($session != null ){
    $path_parts = $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
    if(basename($path_parts) == 'login.php' || basename($path_parts) == 'signup.php' || basename($path_parts) == 'forgot-password.php')
        header('Location:/used-cars/');
}
$id = isset($_GET['id']) ? $_GET['id'] : null;
$type = isset($_GET['type']) ? $_GET['type'] : null;
$action = isset($_GET['action']) ? $_GET['action'] : null;
$id = $session;
$user = wpagent::read("SELECT * FROM wp_agents WHERE id =$id LIMIT 1",PDO::FETCH_CLASS,'wpagent');

$typebrand= isset($_GET['typebrand']) ? other::security($_GET['typebrand']) : 0;
$brandid= isset($_GET['brandid']) ? other::security($_GET['brandid']) : 0;
$brandid = str_replace('-', ' ', $brandid);
$modelid = isset($_GET['carmodel']) ? other::security($_GET['carmodel']) : null;
$modelid = str_replace('-', ' ', $modelid);
$car_id = isset($_GET['car_id']) ? other::security($_GET['car_id']) : null;
$car_id = str_replace('-', ' ', $car_id);
$cars = isset($_GET['car']) ? other::security($_GET['car']) : null;
$cars = str_replace('-', ' ', $cars);
 
?>
<!DOCTYPE html>
<html>
<head>
    <?php require_once('../include/seo.php'); 
    $template= new Template();
    $template->SetHead();
    ?>
    <link href="/assets/css/jquery.bxslider.css" rel="stylesheet">
    <link href="/assets/css/animate.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="/used-cars/assets/css/slider.css">
    <link rel="stylesheet" type="text/css" href="/used-cars/assets/linearicons\style.css">
    <link rel="stylesheet" type="text/css" href="/used-cars/assets/fonts\flaticon\font\flaticon.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.2/css/bootstrap-select.min.css">
    <link rel="stylesheet" type="text/css" href="/used-cars/assets/css\ionicons\css\ionicons.min.css">
    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800%7CPlayfair+Display:400,700%7CRoboto:100,300,400,400i,500,700">
    <!-- Custom stylesheet -->
    <link rel="stylesheet" type="text/css" href="/used-cars/assets/css/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="/used-cars/assets/css/colors/default.css">
    <link rel="stylesheet" type="text/css" href="/used-cars/assets/carouselengine/initcarousel-1.css">
<meta property="fb:app_id" content="1598825893767497" />
 <!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');

fbq('init', '1663446093905282');
fbq('track', "PageView");</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=1663446093905282&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
<!-- Facebook Pixel Code New -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');

fbq('init', '1271797509515362');
fbq('track', "PageView");</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=1271797509515362&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-M6QHJJJ');</script>
<!-- End Google Tag Manager -->
</head>