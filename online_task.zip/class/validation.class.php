<?php 
class validation extends DatabaseModel {
    public static function ValidateValue($value,$inputname,$conditions)
    {
        for ($counter=0; $counter < count($conditions) ; $counter++) {
            $function=$conditions[$counter];
            $range=(isset($conditions[$counter][1])&&!empty($conditions[$counter][1]))?$conditions[$counter][1]:0;$rf=(is_array($function))?$function[0]:$function;
            $error = (!is_array($function))?self::$rf($value,$inputname):self::$rf($value,$inputname,$range); //call function of validation
            if (is_string($error)) {
                return $error;
            }
        }
        return true;
    }
    public static function is_exsist($value,$inputname,$table,$column)
    {
        $isExsist=self::read("SELECT * FROM $table Where $column = $value ",PDO::FETCH_CLASS,__CLASS__);
        return ($isExsist!=null)?true:$inputname.' Should Be Valid';
    }

    public static function email($value,$inputname) 
    {return filter_var($value, FILTER_VALIDATE_EMAIL)?true:$inputname.' Please Enter Valid Email';}
    
    public static function required($value,$inputname) 
    {return (strlen($value) !== 0)?true:$inputname.' Shouldn\'t be empty';}

    public static function numeric($value,$inputname)
    {return (is_numeric($value))?true:$inputname.' Should Be Numeric';}

    public static function notnumeric($value,$inputname)
    {return (!is_numeric($value))?true:$inputname.'Should\'t Be Numeric';}

    public static function strings($value,$inputname)
    {return (is_string($value))?true:$inputname.' Should Be Characters';}

    public static function is_date($value,$inputname)
    {
        $d = DateTime::createFromFormat('Y-m-d', $value);
        return ($d && $d->format('Y-m-d') === $value)?true:$inputname.' Should Be Valid Date';
    }
    public static function is_in_array($value,$inputname,$array)
    {
        return (in_array($value, $array))?true:$inputname.' Should Be One Of This Elements '.self::serialize_style($array);
    }
    public static function serialize_style($array)
    {
        $res = '(';$counter=1;
        foreach ($array as $arr) {$res.=(($counter!=1)?',':'').$arr;$counter++;}
        return $res.')';
    }
}