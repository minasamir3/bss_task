<?php 
class other extends DatabaseModel {
    // This Function To Rewrite URL
    public static function urls($url){
        $newurl = rtrim($url);
        $newurl = ltrim($newurl);
        $newurl = mb_strtolower ($newurl, 'UTF-8');
        $newurl = str_replace(' ', '-', $newurl);
        $newurl = str_replace('/', '-', $newurl);
        $newurl = str_replace('%', '-', $newurl);
        $newurl = str_replace('"', '-', $newurl);
        $newurl = str_replace('&', '-', $newurl);
        $newurl = str_replace('.', '-', $newurl);
        $newurl = str_replace('---','-',$newurl);
        $newurl = str_replace('--', '-',$newurl);
        $url = $newurl;
        return $url;
    }
    // HTML Secure Input
    
    public static function security($input)
    {
        $input = strip_tags($input);
        $input = htmlentities($input, ENT_QUOTES, 'UTF-8');
        $input = str_replace('/', '&#x2F;', $input);
        $input = str_replace('"', '&quot;', $input);
        $input = str_replace("'", '&rsquo;', $input);
        $input = str_replace("#", '%23', $input);
        //$input = str_replace("-", 'dash', $input);
        $input = str_replace("--", 'doubledash', $input);
        $input = str_replace(";", 'semicol', $input);
        $input = strip_tags($input);
        $input = stripslashes($input);
        $input = trim($input);
        $input = rtrim($input);
        $input = ltrim($input);
        return $input;
    }
    // Remove HTML Tags
    public static function removeTage($input){
        if($input !=null){
            $input =strip_tags($input);
            return $input;
        }
    }
    public static function WhiteSpace($word){
        $word = rtrim($word);
        $word = ltrim($word);
        return $word;
    }
    // Date Write ar
    public static function namesday($nameday){
         switch ($nameday) 
{ 
case "Saturday": 
$nameday="Saturday"; 
break; 
case "Sunday": 
$nameday="Sunday"; 
break; 
case "Monday": 
$nameday="Monday"; 
break; 
case "Tuesday": 
$nameday="Tuesday"; 
break; 
case "Wednesday": 
$nameday="Wednesday"; 
break; 
case "Thursday": 
$nameday="Thursday"; 
break; 
case "Friday": 
$nameday="Friday"; 
break; 
}  
        return $nameday;
    }
    public static function namesmonth($namemonth){
        switch ($namemonth) 
{ 
case 1: 
$namemonth="يناير"; 
break; 
case 2: 
$namemonth="فبراير"; 
break; 
case 3: 
$namemonth="مارس"; 
break; 
case 4: 
$namemonth="إبريل"; 
break; 
case 5: 
$namemonth="مايو"; 
break; 
case 6: 
$namemonth="يونيو"; 
break; 
case 7: 
$namemonth="يوليو"; 
break; 
case 8: 
$namemonth="اغسطس"; 
break; 
case 9: 
$namemonth="سبتمبر"; 
break; 
case 10: 
$namemonth="اكتوبر"; 
break; 
case 11: 
$namemonth="نوفمبر"; 
break; 
case 12: 
$namemonth="ديسمبر"; 
break; 
} 
        return $namemonth;
    }
    public static function am($am){
        switch($am){
            case 'am':
                $am='ص';
                break;
            case 'pm':
                $am='م';
                break;
        }
        return $am;
    }
    // convert Array To string
    public static function savearray($array){
    $arrayss= $array;
    $table='';
    if(is_object($arrayss)){
        $table .=$arrayss[0];
    }else{
       foreach($arrayss as $array){
           $table .= $array .',';
       }$table .=' ';
    }
        return $table;
}
    // convert  string to array And Search
    public static function returnarray($array,$key){
      $array = explode(",",$array);
      $return = in_array($key, $array, true); 
    
     return $return;
    }
     // convert  string to array And Return Array
    public static function arrays($array){
      $array = explode(",",$array); 
     return $array;
    }
    // Limit Text Word
    public static function limitword($str,$size){
    if (strlen($str) > $size){
    $str = substr($str, 0, $size) . '...';
    }
    return $str;
    }
    // Convert Number EN TO AR
    public static function numberar($num){ 
    $num=str_replace("1","١",$num); 
    $num=str_replace("2","٢",$num); 
    $num=str_replace("3","٣",$num); 
    $num=str_replace("4","٤",$num); 
    $num=str_replace("5","٥",$num); 
    $num=str_replace("6","٦",$num); 
    $num=str_replace("7","٧",$num); 
    $num=str_replace("8","٨",$num); 
    $num=str_replace("9","٩",$num); 
    $num=str_replace("0","٠",$num); 
    return $num; 
    }
    // Get Time & Date
    public static function getTime(){
    // Date Setting 
    $namesday=date("l");
    $part1= other::namesday($namesday) .' - ';
    $part2=date("j");
    $namemonth=date("m");
    $part3= ' '. other::namesmonth($namemonth);
    $part4= ' '.$yearss=date("Y") ;
    $part5= ' - '. $time=date('h:i');
    $am= date('a');
    $part6=other::am($am);
    $created=  $part2 .' - '. $part3 .' '.$part4.$part5.' '.$part6;
    return $created;
    }
    public static function ConverTime($date){
    $date = new DateTime($date);
    // Date Setting 
    $namesday=$date->format("l");
    $part1= other::namesday($namesday) .' - ';
    $part2=$date->format("j");
    $namemonth=$date->format("m");
    $part3= ' '. other::namesmonth($namemonth);
    $part4= ' '.$yearss=$date->format("Y") ;
    $part5= ' - '. $time=$date->format('h:i');
    $am= $date->format('a');
    $part6=other::am($am);
    $created=  $part2 .' - '. $part3 .' '.$part4.$part5.' '.$part6;
    return $created;
    }
    public static function ConverTimeMobile($date){
    $date = new DateTime($date);
    // Date Setting 
    $part1=$date->format("j");
    $namemonth=$date->format("m");
    $part2= $namemonth;
    $part3= $yearss=$date->format("Y");
    $created= ' '.$part1 .' - '. $part2 .' - '.$part3;
    return $created;
    }
    // Check Mobile
    public static function isMobile() {
    return preg_match("/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);
}
    //
    public static function urlExists($url) {
        $file = $url;
        $file_headers = @get_headers($file);
        if(!$file_headers || $file_headers[0] == 'HTTP/1.1 404 Not Found') {
            return false;
        }
        else {
            return true;
        }
    }
    public static function optionAllGov($gov){
        $alloption = self::read("SELECT * FROM governorates", PDO::FETCH_CLASS,__CLASS__);
        $table = '<option selected value="%">الكل</option>';
        if($alloption !== false)
        {
            foreach($alloption as $options){
                if($gov == $options->id || $gov == $options->name)
                    $table .= '<option value='.$options->id.' selected>'.$options->name.'</option>';
                else
                    $table .= '<option value='.$options->id.'>'.$options->name.'</option>';
            }

        }
     $table .='';
     return $table;    
    }
}