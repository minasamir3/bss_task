<?php
class task extends DatabaseModel {
    public $id;public $t_title;
    public $t_description;public $status;public $t_sort;
    public $t_created;public $t_group;public $tablename ="task";
    public $dbfields = array('id','t_title','t_description','status','t_sort','t_created','t_group');
    public static function GetTasks($group='a')
    {
        $tasks = self::read("SELECT * FROM task WHERE t_group='$group' ORDER BY t_sort asc , SUBSTRING( id FROM 1 FOR 1 ) desc",PDO::FETCH_CLASS,__CLASS__);
        $result='
                    <ol class="dd-list">';
        if ($tasks!=null) {
            if (is_object($tasks)) {
                $result.='<li class="dd-item dd3-item task-sec" TaskIdentity="'.$tasks->id.'" TaskGroup="'.$tasks->t_group.'">
                            <div class="dd-handle dd3-handle"></div>
                            <div class="dd3-content" >
                                <span class="task-title-sp"><span class="task-title-editable" >'.$tasks->t_title.'</span></span>
                                <span class="task-del-sp"></span>
                                <span class="btn btn-sm task-date-sp float-right"><span class="task-date-editable" >'.$tasks->t_created.'</span></span>
                                <span class="btn btn-sm task-status-sp float-right"><span class="task-status-editable" >'.$tasks->status.'</span></span>
                            </div>
                        </li>';
            }else
            {
                foreach ($tasks as $tasks) {
                    $result.='<li class="dd-item dd3-item task-sec" TaskIdentity="'.$tasks->id.'" TaskGroup="'.$tasks->t_group.'">
                            <div class="dd-handle dd3-handle"></div>
                            <div class="dd3-content" >
                                <span class="task-title-sp"><span class="task-title-editable" >'.$tasks->t_title.'</span></span>
                                <span class="task-del-sp"></span>
                                <span class="btn btn-sm task-date-sp float-right"><span class="task-date-editable" >'.$tasks->t_created.'</span></span>
                                <span class="btn btn-sm task-status-sp float-right"><span class="task-status-editable" >'.$tasks->status.'</span></span>
                            </div>
                        </li>';
                }
            }
        }
        return $result.'</ol><br><span cols="30" rows="3" class="btn btn-outline-primary float-right">
                                <a href="#largeModal" class="add-task-btn" data-toggle="modal" data-target="#largeModal">
                                <i class="fa fa-plus"></i> New Item</a></span>
                        <br>';
    }
    public static function UpdateOneInput($id,$column,$value)
    {
        $task = self::read("SELECT * FROM task WHERE id=$id",PDO::FETCH_CLASS,__CLASS__);
        if ($task!=null) {
            $task->{$column}=$value;
            return ($task->save())?true:false;
        }return false;
    }
    public static function ReturnSpicifColumn($id,$column)
    {
        $task = self::read("SELECT $column FROM task WHERE id=$id",PDO::FETCH_CLASS,__CLASS__);
        return ($task!=null)?$task->{$column}:'';
    }
    public static function GetMinumSort()
    {
        $task = self::read("SELECT min(t_sort) as sort FROM task",PDO::FETCH_CLASS,__CLASS__);
        return ($task!=null && $task->sort<1)?$task->sort:0;
    }
    public static function GetTaskDetails($id)
    {
        $task = self::read("SELECT * FROM task WHERE id=$id",PDO::FETCH_CLASS,__CLASS__);
        $result='';
        if ($task!=null) {
            $result.='<h3>'.$task->t_title.'</h3>
                            <p>'.$task->t_description.'</p>
                        <form id="savecomment" class="register form-horizontal" method="post" redirecturl="getajaxdata.php">
                            <input type="text" class="form-control" name="comment" placeholder="Write a Comment">
                            <input type="hidden" name="case" value="10">
                            <input type="hidden" name="tid" value="'.$task->id.'">
                            <input type="submit" style="display:none;" onclick="ajaxFormSend(\'savecomment\')">
                        </form>
                        <div id="task_comments_'.$task->id.'">'.comment::GetComments($id).'</div>';
        }
        return $result;
    }
    public static function DeleteTask($id)
    {
        $task = self::read("SELECT * FROM task WHERE id=$id",PDO::FETCH_CLASS,__CLASS__);
        return ($task->delete())?true:false;
    }
}