<?php
class comment extends DatabaseModel {
    public $id;public $c_task_id;
    public $c_comment;public $c_created;public $tablename ="comment";
    public $dbfields = array('id','c_task_id','c_comment','c_created');
    public static function GetComments($task_id)
    {
        $comments = self::read("SELECT * FROM comment WHERE c_task_id=$task_id order by id desc",PDO::FETCH_CLASS,__CLASS__);
        $result='<div class="card">
                            <div class="header">
                                <h2>Comments '.self::GetCommentsCount($task_id).'</h2>
                            </div>
                            <div class="body"><ul class="comment-reply list-unstyled">';
        if ($comments!=null) {
            if (is_object($comments)) {
                $result.='<li class="row clearfix">
                            <div class="icon-box col-md-2 col-4"><img class="img-fluid img-thumbnail" src="/assets/images/sm/person.jpg" alt="person"></div>
                            <div class="text-box col-md-10 col-8 p-l-0 p-r0">
                                <p>'.$comments->c_comment.'.</p>
                                <ul class="list-inline">
                                    <li><a href="javascript:void(0);">'.$comments->c_created.'</a></li>
                                </ul>
                            </div>
                        </li>';
            }else
            {
                foreach ($comments as $comments) {
                    $result.='<li class="row clearfix">
                            <div class="icon-box col-md-2 col-4"><img class="img-fluid img-thumbnail" src="/assets/images/sm/person.jpg" alt="person"></div>
                            <div class="text-box col-md-10 col-8 p-l-0 p-r0">
                                <p>'.$comments->c_comment.'.</p>
                                <ul class="list-inline">
                                    <li><a href="javascript:void(0);">'.$comments->c_created.'</a></li>
                                </ul>
                            </div>
                        </li>';
                }
            }
        }
        return $result.'</ul></div></div>';
    }
    public static function GetCommentsCount($task_id)
    {
        $comments_count = self::read("SELECT count(id) as count FROM comment WHERE c_task_id=$task_id",PDO::FETCH_CLASS,__CLASS__);
        return ($comments_count!=null)?$comments_count->count:0;
    }
}