<?php require_once('include/header.php'); ?>
    <div id="main-content">
        <div class="container-fluid">
            <div class="row clearfix">
                <div class="col-lg-6 col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2>Group A <small>Drag & drop</small> </h2>
                        </div>
                        <div class="body">
                            <div class="clearfix m-b-20" >
                                <div class="dd group-sec" id="group_table_a" TaskGroup="a">
                                <?php echo task::GetTasks('a');?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2>Group B<small>Drag & drop</small> </h2>
                        </div>
                        <div class="body">
                            <div class="clearfix m-b-20">
                                <div class="dd group-sec" id="group_table_b" TaskGroup="b">
                                <?php echo task::GetTasks('b');?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<div class="modal fade" id="largeModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="title" id="largeModalLabel">Add Task</h4>
            </div>
            <form id="save" class="register form-horizontal" method="post" redirecturl="getajaxdata.php">
                <div class="modal-body"> 
                    <div id="result"></div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4">
                            <input type="hidden" name="group_input" value="a" required>
                            <input type="hidden" name="case" value="1" required>
                            <label class="control-label">Task Title</label><br>
                            <input type="text" class="form-control" name="task_title" required>
                        </div>
                        <div class="col-lg-4 col-md-4">
                            <label class="control-label">Task Date</label><br>
                            <input type="date" class="form-control" name="task_date" required>
                        </div>
                        <div class="col-lg-4 col-md-4">
                            <label class="control-label">Task Status</label><br>
                            <select class="form-control" name="task_status"><option disabled selected>Choose</option><option value="Done">Done</option><option value="Delayed">Delayed</option><option value="Pending">Pending</option></select>
                        </div><hr class="col-md-12">
                        <div class="col-lg-12 col-md-12">
                            <label class="control-label">Task Description</label><br>
                            <textarea class="form-control" name="task_description" required></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" onclick="ajaxFormSend('save')">SAVE</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">CLOSE</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="DetailsModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="title" id="DetailsModalLabel">Task Details</h4>
            </div>
            <div class="modal-body" id="DetailsModelContentId"></div>
            
        </div>
    </div>
</div>
<?php
    require_once('include/footer.php');?>
    <script type="text/javascript">
        
  socket.on( 'new_task', function( data ) {
    var group = data.data.group;
    $('#group_table_'+group).html(GetTasksJs(group));
  });

  socket.on( 'new_comment', function( data ) {
    var task_id = data.data.tid;
    $('#task_comments_'+task_id).html(GetCommentsJs(task_id));
  });
    </script>