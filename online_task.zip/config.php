<?php 
// Setting Output Buffer
ob_start();
// Session Start 
session_start();

//Error Handling
ini_set('max_execution_time', 0);
ini_set('display_errors',1);

// Define App 
//shortcuts if / or \
define('DS',DIRECTORY_SEPARATOR);

// shourcuts if ; or ,
define('PS', PATH_SEPARATOR);

//Domin Related
if (isset($_SERVER['HTTPS']) &&
    ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
    isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
    $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
  $protocol = 'https://';
}
else {
  $protocol = 'http://';
}
// Get Domain
define('HOST_NAME',$protocol.$_SERVER['HTTP_HOST']);
define('HOST_NAME2',$protocol.$_SERVER['HTTP_HOST']);
// Get Full URL
define('URL',$protocol.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
// Get Login Page
define('LOGIN_URL',$protocol.$_SERVER['HTTP_HOST'].DS.'login.php');
// Get Logout Page
define('LOGOUT_URL',$protocol.$_SERVER['HTTP_HOST'].DS.'logout.php');
// CSS & JS & IMG Path 
define('CSS_DIR',HOST_NAME .DS.'assets'.DS.'css'.DS);
define('JS_DIR',HOST_NAME .DS.'assets'.DS.'js'.DS);
define('IMG_DIR',HOST_NAME.DS.'assets'.DS.'img'.DS);
// Main path
define('APP_PATH',realpath(dirname(__FILE__). DS.DS));

// Class Files Path
define('CLASS_PATH', APP_PATH . DS .'class' . DS);
// because import class and modules from folder
// Set The new Paths  To called Class 
$path= get_include_path() . PS . CLASS_PATH. PS;
set_include_path($path);
function __autoload($class)
{
    require_once strtolower($class) . '.class.php';
}
date_default_timezone_set('Egypt');

define('DB_HOST','localhost');
define('DB_NAME','companys_asaserp');
define('DB_USER','companys_mina');
define('DB_PASS','QE(vx0r&8QgT');
$dbh= Database::getInstance(); //Database Credentials (Database 1) Primary Database
