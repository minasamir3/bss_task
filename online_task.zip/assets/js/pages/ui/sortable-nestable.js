$(function () {
    $('.dd').nestable();
    $('body').on('change','.dd',function(){
        var $this = $(this);
        $($this).nestable('serialize');
    });

    $('.dd4').nestable();
    $('.dd4').on('change', function () {
        var $this = $(this);
        var serializedData = window.JSON.stringify($($this).nestable('serialise'));
    });
});