var baseurl=document.getElementById("baseurl").getAttribute("href")+'/',redirecturl = baseurl+'/getajaxdata.php';

var socket = io.connect( 'http://'+window.location.hostname+':3000' );//node js call
function SaveGroupData(array)//array of elements (task id , task sort , task group)
{
	$.ajax({
        type:"POST",url:redirecturl,data: {case:11,'data':array}
        ,async: false,cache: false,dataType:"json",  
        success: function( data )
        {
          socket.emit('new_task', {group: array[0][2]});
          result=data.result;
        },
        error: function(data)
        {alert(data.msg);}
      });
	return result;
}
$('body').on('click','.task-title-editable',function(){
	var col_id=$(this).closest(".task-sec").attr('TaskIdentity');
	$(this).closest(".task-title-sp").html('<input class="input_title" type="text" value="'+GetTaskColumnValue(col_id,2)+'" >');
});
function GetTaskColumnValue(col_id,kcase)
{
    var result='';
	$.ajax({
        type:"POST",url:redirecturl,data: {'case':kcase,'col_id':col_id}
        ,async: false,cache: false,dataType:"json",  
        success: function( data )
        {result=data.result;},
        error: function(data)
        {alert(data.msg);}
      });
	return result;
}
function DisplayTaskDetails(col_id)
{
	$.ajax({
        type:"POST",url:redirecturl,data: {'case':9,'col_id':col_id}
        ,async: false,cache: false,dataType:"json",  
        success: function( data )
        {$('#DetailsModelContentId').html(data.result)},
        error: function(data)
        {alert(data.msg);}
      });
	$('#DetailsModal').modal('show'); 
}
$('body').on('change','.input_title',function(){
	var col_id=$(this).closest(".task-sec").attr('TaskIdentity'),newTitle=$(this).val(),
  group=$(this).closest(".group-sec").attr('TaskGroup');
	$.ajax({
        type:"POST",url:redirecturl,data: {'case':3,'col_id':col_id,'newtitle':newTitle}
        ,async: false,cache: false,dataType:"json",  
        success: function( data )
        {socket.emit('new_task', {group: group});}
      });
	DisplayDivTitle(this,col_id);
});
function DisplayDivTitle(element,id)
{
	$(element).closest(".task-title-sp").html('<span class="task-title-editable">'+GetTaskColumnValue(id,2)+'</span>');
}

$('body').on('click','.delete-task',function(){
	var col_id=$(this).closest(".task-sec").attr('TaskIdentity'),
  group=$(this).closest(".group-sec").attr('TaskGroup');
	if(confirm("Are U sure U Want To Delete This Task ? ")){
	 $.ajax({
        type:"POST",url:redirecturl,data: {'case':8,'col_id':col_id}
        ,async: false,cache: false,dataType:"json",  
        success: function( data )
        {socket.emit('new_task', {group: group});}
      });
    };
});

$('body').on('click','.task-date-editable',function(){
	var col_id=$(this).closest(".task-sec").attr('TaskIdentity');
	$(this).closest(".task-date-sp").html('<input type="date" class="input_date" name="input_date" value="'+GetTaskColumnValue(col_id,4)+'">');
});
$('body').on('change','.input_date',function(){
	var col_id=$(this).closest(".task-sec").attr('TaskIdentity'),created=$(this).val();
	$.ajax({
        type:"POST",url:redirecturl,data: {'case':5,'col_id':col_id,'created':created}
        ,async: false,cache: false,dataType:"json"
      });
	DisplayDivDate(this,col_id);
});
function DisplayDivDate(element,col_id)
{$(element).closest(".task-date-sp").html('<span class="task-date-editable">'+GetTaskColumnValue(col_id,4)+'</span>');}


$('body').on('click','.task-status-editable',function(){
	var col_id=$(this).closest(".task-sec").attr('TaskIdentity');
	$(this).closest(".task-status-sp").html('<select class="input_status"><option disabled selected>Choose</option><option value="Done">Done</option><option value="Delayed">Delayed</option><option value="Pending">Pending</option></select>');
});
$('body').on('change','.input_status',function(){
	var col_id=$(this).closest(".task-sec").attr('TaskIdentity'),status=$(this).val();
	$.ajax({
        type:"POST",url:redirecturl,data: {'case':7,'col_id':col_id,'status':status}
        ,async: false,cache: false,dataType:"json"
      });
	DisplayDivStatus(this,col_id);
});
function DisplayDivStatus(element,col_id)
{$(element).closest(".task-status-sp").html('<span class="task-status-editable">'+GetTaskColumnValue(col_id,6)+'</span>');}

$('body').on('click','.dd3-content',function(e){
	if(e.target == this){
		var col_id=$(this).closest(".task-sec").attr('TaskIdentity');	
		$(this).closest(".task-sec").find('.task-del-sp').html('');
		DisplayTaskDetails(col_id);
   }
});
$('body').on('mouseover','.dd3-content',function(e){
	if(e.target == this){$(this).closest(".task-sec").find('.task-del-sp').html('');}
});
$('body').on('mouseover','.task-title-sp,.task-date-sp,.task-status-sp',function(e){
	if(e.target != this){
	var col_id=$(this).closest(".task-sec").attr('TaskIdentity');
	$(this).closest(".task-sec").find('.task-del-sp').html('<a class="delete-task"><span class="btn btn-outline-danger btn-sm float-right"><i class="fa fa-trash"></i></span></a>');
   }
});

$('body').on('click','.add-task-btn',function(){
	var group=$(this).closest(".group-sec").attr('TaskGroup');
	$('input[name=group_input]').val(group);
});
function ajaxFormSend(formId){
  $('#'+formId).submit(function(e) {
    e.preventDefault();e.stopImmediatePropagation();
    var redirecturl = baseurl+document.getElementById(formId).getAttribute("redirecturl");
    var formData = new FormData($(this)[0]);formRdata=$(this).serializeObject();
      $.ajax({
        type:"POST",url:redirecturl,
        data:formData,processData: false,
        contentType: false,dataType:"json",   
        success: function( data )
        {
          if(data.type == "success")
          {
            if (formId=='savecomment') {socket.emit('new_comment', {tid: formRdata.tid});}
            else{socket.emit('new_task', {group: formRdata.group_input});}
            $('#'+formId)[0].reset();
            document.getElementById('result').innerHTML ='<div class="alert alert-success" role="alert">'+data.msg+'</div>';
            $('#largeModal').modal('hide');
            goToByScroll('result');
          }

          else
          {document.getElementById('result').innerHTML ='<div class="alert alert-danger" role="alert">'+data.msg+'</div>';goToByScroll('result');}               
        },
        error: function(data)
        {alert(data.msg);}
      });
    });
  return true;
}
function goToByScroll(id) {
    // Scroll
    $('html,body').animate({scrollTop: $("#" + id).parent().offset().top}, 'slow');
}
$.fn.serializeObject = function() {
  var o = {};
  var a = this.serializeArray();
  $.each(a, function() {
    if (o[this.name]) {
      if (!o[this.name].push) {
        o[this.name] = [o[this.name]];
      }
      o[this.name].push(this.value || '');
    } else {
      o[this.name] = this.value || '';
    }
  });
  return o;
}
function GetTasksJs(group)
{
    var result='';
  $.ajax({
        type:"POST",url:redirecturl,data: {'case':12,'group':group}
        ,async: false,cache: false,dataType:"json",  
        success: function( data )
        {result=data.result;},
        error: function(data)
        {alert(data.msg);}
      });
  return result;
}
function GetCommentsJs(tid)
{
    var result='';
  $.ajax({
        type:"POST",url:redirecturl,data: {'case':13,'tid':tid}
        ,async: false,cache: false,dataType:"json",  
        success: function( data )
        {result=data.result;},
        error: function(data)
        {alert(data.msg);}
      });
  return result;
}